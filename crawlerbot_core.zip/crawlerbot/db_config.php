<?php
/* DATABASE */
define('BOT_HOST','localhost');
define('BOT_USERNAME','root');
define('BOT_PASSWORD','123456');
define('BOT_DATABASE','insidemusic');

<?php
if ( ! defined('VBOT')) exit('No direct script access allowed');
/*
 * interface plugin for crawler
 */
interface iplugin{	
	//method
	public function start();
}